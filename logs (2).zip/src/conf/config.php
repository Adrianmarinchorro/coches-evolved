<?php

namespace App\conf;

class config{

   public static $DB_HOST =  "localhost";
   public static $DB_USER = "root";
   public static $DB_PASS = "root";
   public static $DB_NAME = "concesionario";
   public static $DB_PORT = 49170;

}